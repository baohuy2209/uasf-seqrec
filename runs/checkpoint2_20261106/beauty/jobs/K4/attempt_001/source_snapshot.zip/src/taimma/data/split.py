"""Chronological Train-base/metadata/validation/test splitting."""

import hashlib
import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, List, Set

from .ingestion import InteractionSequence
from ..paths import resolve_project_path


@dataclass
class SequenceSample:
    user_idx: int
    history: List[int]
    target: int
    history_len: int
    raw_target_asin: str = ""


@dataclass
class SplitData:
    train_base_samples: List[SequenceSample]
    train_meta_samples: List[SequenceSample]
    val_samples: List[SequenceSample]
    test_samples: List[SequenceSample]
    item2idx: Dict[str, int]
    idx2item: Dict[int, str]
    user2idx: Dict[str, int]
    num_items: int
    num_users: int
    oov_counts: Dict[str, int]
    seen_train_items_per_user: Dict[int, Set[int]]
    train_base_events: List[int] = None

    def __post_init__(self):
        if self.train_base_events is None:
            self.train_base_events = [
                sample.target for sample in self.train_base_samples
            ]


class SequenceSplitter:
    def __init__(
        self, max_seq_len: int = 50, min_seq_len: int = 5,
        include_oov_in_eval: bool = True, protocol: str = "four_segment"
    ):
        if protocol not in ("four_segment", "loo"):
            raise ValueError(f"Unknown split protocol: {protocol}")
        self.max_seq_len = max_seq_len
        self.min_seq_len = min_seq_len
        self.include_oov_in_eval = include_oov_in_eval
        self.protocol = protocol

    def split(self, sequences: List[InteractionSequence]) -> SplitData:
        eligible = [s for s in sequences if len(s.items) >= self.min_seq_len]
        user2idx = {s.user_id: i for i, s in enumerate(eligible)}
        catalog_items = []
        for sequence in eligible:
            n = len(sequence.items)
            catalog_end = n - 3 if self.protocol == "four_segment" else n - 2
            catalog_items.extend(sequence.items[:catalog_end])
        # Metadata rows and embeddings use sorted raw IDs. Keep model IDs
        # independent of the order in which users/items occur in the input.
        item2idx = {item: idx for idx, item in enumerate(sorted(set(catalog_items)), 1)}
        idx2item = {idx: item for item, idx in item2idx.items()}
        result = {
            "train_base_samples": [], "train_meta_samples": [],
            "val_samples": [], "test_samples": [],
        }
        oov_counts = {"train_meta": 0, "val": 0, "test": 0}
        seen: Dict[int, Set[int]] = {i: set() for i in user2idx.values()}

        def make_sample(user_idx, items, target):
            mapped = [item2idx.get(item, 0) for item in items[-self.max_seq_len:]]
            history_len = sum(item > 0 for item in mapped)
            history = [0] * (self.max_seq_len - len(mapped)) + mapped
            target_idx = item2idx.get(target, 0)
            return SequenceSample(user_idx, history, target_idx, history_len, target)

        for sequence in eligible:
            user_idx = user2idx[sequence.user_id]
            items = sequence.items
            n = len(items)
            train_end = n - 3 if self.protocol == "four_segment" else n - 2
            for target_pos in range(1, train_end):
                sample = make_sample(user_idx, items[:target_pos], items[target_pos])
                result["train_base_samples"].append(sample)
                if sample.target:
                    seen[user_idx].add(sample.target)
            if self.protocol == "four_segment":
                meta_pos = n - 3
                meta = make_sample(user_idx, items[:meta_pos], items[meta_pos])
                result["train_meta_samples"].append(meta)
                if not meta.target:
                    oov_counts["train_meta"] += 1
            for name, pos in (("val", n - 2), ("test", n - 1)):
                sample = make_sample(user_idx, items[:pos], items[pos])
                if sample.target or self.include_oov_in_eval:
                    result[f"{name}_samples"].append(sample)
                if not sample.target:
                    oov_counts[name] += 1
        return SplitData(
            **result, item2idx=item2idx, idx2item=idx2item, user2idx=user2idx,
            num_items=len(item2idx), num_users=len(eligible),
            oov_counts=oov_counts, seen_train_items_per_user=seen,
            train_base_events=[
                sample.target for sample in result["train_base_samples"] if sample.target
            ],
        )


def compute_file_sha256(path: str) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def save_processed_data(processed_dir, split_data: SplitData, raw_reviews_path: str, config: Dict):
    output = resolve_project_path(processed_dir)
    output.mkdir(parents=True, exist_ok=True)
    item2idx_path = output / "item2idx.json"
    user2idx_path = output / "user2idx.json"
    stats_path = output / "stats.json"
    manifest_path = output / "manifest.json"
    item2idx_path.write_text(json.dumps(split_data.item2idx, indent=2), encoding="utf-8")
    user2idx_path.write_text(json.dumps(split_data.user2idx, indent=2), encoding="utf-8")
    stats_path.write_text(json.dumps({
        "num_items": split_data.num_items, "num_users": split_data.num_users,
        "oov_counts": split_data.oov_counts,
    }, indent=2), encoding="utf-8")
    manifest_path.write_text(json.dumps({
        "raw_reviews_file": str(resolve_project_path(raw_reviews_path)),
        "raw_reviews_sha256": compute_file_sha256(raw_reviews_path),
        "config": config,
        "stats": {"num_items": split_data.num_items, "num_users": split_data.num_users},
    }, indent=2), encoding="utf-8")
    return {
        "item2idx": str(item2idx_path), "user2idx": str(user2idx_path),
        "stats": str(stats_path), "manifest": str(manifest_path),
    }
