"""Amazon 2014 review ingestion with explicit, repository-relative paths."""

import ast
import gzip
import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from ..paths import resolve_project_path


@dataclass
class InteractionSequence:
    user_id: str
    items: List[str]
    timestamps: List[float]


class Amazon2014Ingestor:
    def __init__(self, raw_data_dir: str = "data/raw", dataset_key: str = "Beauty"):
        self.raw_data_dir = resolve_project_path(raw_data_dir)
        self.dataset_key = dataset_key
        self.reviews_path: Optional[str] = None
        self.meta_path: Optional[str] = None
        self.ratings_path: Optional[str] = None

    def resolve_paths(self) -> Tuple[str, Optional[str]]:
        directories = list(dict.fromkeys([
            self.raw_data_dir,
            self.raw_data_dir / self.dataset_key,
            self.raw_data_dir / self.dataset_key.replace("_", " "),
        ]))

        def locate(names):
            for directory in directories:
                for name in names:
                    for suffix in ("", ".gz"):
                        path = directory / (name + suffix)
                        if path.is_file():
                            return str(path)
            return None

        reviews = locate([f"reviews_{self.dataset_key}_5.json", f"{self.dataset_key}_5.json"])
        if reviews is None:
            raise FileNotFoundError(
                f"[TAIMMA Data Error] Missing raw reviews file for "
                f"{self.dataset_key} under {self.raw_data_dir}"
            )
        metadata = locate([f"meta_{self.dataset_key}.json"])
        self.ratings_path = locate([f"ratings_{self.dataset_key}.csv"])
        self.reviews_path = reviews
        self.meta_path = metadata
        return reviews, metadata

    @staticmethod
    def _records(path: str):
        opener = gzip.open if str(path).endswith(".gz") else open
        with opener(path, "rt", encoding="utf-8") as handle:
            for line in handle:
                line = line.strip()
                if line:
                    try:
                        yield json.loads(line)
                    except json.JSONDecodeError:
                        # Original Amazon 2014 metadata uses Python literals.
                        yield ast.literal_eval(line)

    @staticmethod
    def _clean_brand(value) -> Optional[str]:
        if not isinstance(value, str):
            return None
        value = re.sub(r"\s+", " ", value).strip()
        return value.casefold() if value and value.casefold() != "unknown" else None

    @staticmethod
    def _clean_categories(value) -> List[str]:
        values = []
        for group in value or []:
            if isinstance(group, str):
                group = [group]
            if isinstance(group, (list, tuple)):
                values.extend(str(x).strip() for x in group if str(x).strip())
        if values:
            root = values[0]
            values = [x for x in values if x != root]
        return list(dict.fromkeys(values))

    def build_interaction_sequences(
        self, min_interactions: int = 5, include_metadata: bool = True
    ):
        reviews_path, metadata_path = self.resolve_paths()
        by_user: Dict[str, List[Tuple[float, int, str]]] = {}
        for order, record in enumerate(self._records(reviews_path)):
            user = record.get("reviewerID")
            item = record.get("asin")
            if user is None or item is None:
                continue
            timestamp = record.get("unixReviewTime", record.get("reviewTime", order))
            try:
                timestamp = float(timestamp)
            except (TypeError, ValueError):
                timestamp = float(order)
            by_user.setdefault(str(user), []).append((timestamp, order, str(item)))

        sequences = []
        for user, rows in by_user.items():
            rows.sort(key=lambda row: (row[0], row[1]))
            if len(rows) >= min_interactions:
                sequences.append(
                    InteractionSequence(
                        user_id=user,
                        items=[row[2] for row in rows],
                        timestamps=[row[0] for row in rows],
                    )
                )

        metadata = self.parse_metadata(metadata_path) if include_metadata and metadata_path else {}
        return sequences, metadata

    def parse_metadata(self, path: str) -> Dict[str, Dict]:
        metadata: Dict[str, Dict] = {}
        for record in self._records(path):
            item = record.get("asin")
            if item is None:
                continue
            metadata[str(item)] = {
                "categories": self._clean_categories(record.get("categories")),
                "brand": self._clean_brand(record.get("brand")),
                "title": record.get("title") if isinstance(record.get("title"), str) else None,
            }
        return metadata
